#include <iostream>
#include <signal.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <errno.h>
#include <cstring>
#define SIZE 40

using namespace std;
